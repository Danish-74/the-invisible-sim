from flask import Flask, jsonify, request

app = Flask(__name__)

subscribers = {
    "1001": {
        "name": "Rahul Sharma",
        "phone": "+919000000001",
        "operator": "Example Telecom"
    },
    "1002": {
        "name": "Priya Verma",
        "phone": "+919000000002",
        "operator": "Example Mobile"
    }
}

# Fictional lab credentials only
tokens = {
    "rahul-lab-token": "1001",
    "priya-lab-token": "1002"
}

@app.route("/subscriber/<subscriber_id>")
def get_subscriber(subscriber_id):

    auth = request.headers.get("Authorization", "")

    if not auth.startswith("Bearer "):
        return jsonify({"error": "Authentication required"}), 401

    token = auth.split(" ", 1)[1]
    authenticated_user = tokens.get(token)

    if authenticated_user is None:
        return jsonify({"error": "Invalid token"}), 401

    if authenticated_user != subscriber_id:
        return jsonify({"error": "Access denied"}), 403

    record = subscribers.get(subscriber_id)

    if not record:
        return jsonify({"error": "Subscriber not found"}), 404

    return jsonify(record), 200


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)
