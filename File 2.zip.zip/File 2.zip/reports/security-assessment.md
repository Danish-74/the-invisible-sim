# Security Assessment Report
## The Invisible SIM — Telecom API Security Research Lab

### 1. Objective
Evaluate how missing authentication and access control can expose simulated subscriber information.

### 2. Environment
- OS: Kali Linux
- Language: Python
- Framework: Flask
- Testing: cURL
- Target: Localhost (127.0.0.1:5000)
- Data: Synthetic subscriber records only

### 3. Initial Vulnerability
The initial API endpoint allowed access to subscriber records without authentication.

Endpoint:
GET /subscriber/<subscriber_id>

### 4. Security Testing

| Test | Expected Result | Actual Result |
|---|---|---|
| No authentication | 401 Unauthorized | 401 |
| Wrong subscriber token | 403 Forbidden | 403 |
| Correct subscriber token | 200 OK | 200 |

### 5. Remediation
- Implemented Bearer token authentication.
- Added subscriber ownership validation.
- Returned appropriate HTTP status codes.
- Restricted the application to localhost.

### 6. Conclusion
The lab demonstrates how missing authentication and authorization checks can expose sensitive information.

Adding authentication and subscriber-level access control reduces this exposure.

### 7. Limitations
This is an educational simulation using hardcoded tokens and fictional data. It is not a production-ready authentication system or a test of a real telecom provider.
